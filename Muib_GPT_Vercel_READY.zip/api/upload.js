import OpenAI from "openai";
import { MUIB_SYSTEM } from "./_system.js";

export const config = { api: { bodyParser: false } };

export default async function handler(req,res){
  if(req.method!=="POST") return res.status(405).json({error:"Method not allowed"});
  res.status(501).json({error:"File upload endpoint needs a multipart parser. Use chat/link first; document/image ingestion will be enabled in the next deployment layer."});
}
