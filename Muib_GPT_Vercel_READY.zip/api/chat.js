import OpenAI from "openai";
import { MUIB_SYSTEM } from "./_system.js";

export default async function handler(req, res) {
  if (req.method !== "POST") return res.status(405).json({error:"Method not allowed"});
  if (!process.env.OPENAI_API_KEY) return res.status(500).json({error:"OPENAI_API_KEY is missing in Vercel Environment Variables."});
  try {
    const { message, mode = "Tutor" } = req.body || {};
    if (!message?.trim()) return res.status(400).json({error:"Message is required."});
    const client = new OpenAI({apiKey: process.env.OPENAI_API_KEY});
    const useWeb = mode === "PYQ Analyst" || /link|url|website|latest|current|pattern/i.test(message);
    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-6-luna",
      instructions: MUIB_SYSTEM,
      input: `MODE: ${mode}\nSTUDENT:\n${message}`,
      ...(useWeb ? {tools:[{type:"web_search_preview"}]} : {})
    });
    res.status(200).json({answer: response.output_text || "No answer returned."});
  } catch (e) {
    console.error(e);
    res.status(500).json({error:e.message || "AI request failed."});
  }
}
