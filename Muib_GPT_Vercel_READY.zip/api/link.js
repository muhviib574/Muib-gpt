import OpenAI from "openai";
import { MUIB_SYSTEM } from "./_system.js";

export default async function handler(req,res){
  if(req.method!=="POST") return res.status(405).json({error:"Method not allowed"});
  if(!process.env.OPENAI_API_KEY) return res.status(500).json({error:"OPENAI_API_KEY is missing in Vercel."});
  try{
    const {url,question="Summarize this page/video and explain JKBOSE relevance."}=req.body||{};
    if(!url) return res.status(400).json({error:"URL is required."});
    const client=new OpenAI({apiKey:process.env.OPENAI_API_KEY});
    const r=await client.responses.create({
      model:process.env.OPENAI_MODEL||"gpt-6-luna",
      instructions:MUIB_SYSTEM,
      input:`Analyze this URL: ${url}\nTask: ${question}\nUse only information you can verify.`,
      tools:[{type:"web_search_preview"}]
    });
    res.status(200).json({answer:r.output_text||"No answer returned."});
  }catch(e){res.status(500).json({error:e.message||"Link analysis failed."})}
}
