# Muib GPT — Vercel build

## Deploy
1. Upload these files to a private GitHub repository.
2. Import the repository into Vercel.
3. Add environment variable `OPENAI_API_KEY`.
4. Optional: add `OPENAI_MODEL` with a model available to your API account.
5. Deploy/redeploy.

Never put the API key in frontend files.

This build provides the mobile JKBOSE tutor UI, server-side AI chat, and URL/web research. The document/image endpoint is intentionally a safe placeholder until a multipart parser is added; do not claim it processed an attachment when it did not.
